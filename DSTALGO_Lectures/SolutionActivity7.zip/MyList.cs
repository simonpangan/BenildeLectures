﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_Activity7Solution
{
    class MyList //data structure
    {
        //methods: implementing algorithm
        int[] array;
        int index = 0; //instance variable/member
        public MyList()
        {
            array = new int[10]; //default size
        }
        public void Add(int item) 
        {
            if (index < array.Length)
            {
                array[index] = item; index++;
            }
            else //if elements exceeded the sie of array
            {
                //throw an exception or
                //resize your array.make it double
            }
        }
        public int Count()
        {
            return index;
        }
        public void PrintList() //console app only
        {
            for (int i = 0; i < index; i++)
            {
                Console.Write("\t" + array[i]);
            }
        }
        public void Sort()
        {
            int temp;
            for (int i = 1; i < index; i++)//insertion sort, up to size of index  ex: 24, 45, 1, 78, 4, 0, 0, 0, 0, 0...etc
            {
                bool swap = true; int insertAt = i;
                for (int j = i; j > 0 && swap; j--)
                {
                    if (array[j] < array[j - 1])
                    {
                        temp = array[j - 1];
                        array[j - 1] = array[j];
                        array[j] = temp; // swap
                        swap = true;
                        insertAt = j - 1;
                    }
                    else swap = false;
                }
            }
        }
        public int Sum()
        {
            int s = 0;
            for (int i = 0; i < index; i++)
            {
                s = s + array[i];
            }
            return s;
        }
        public double Average()
        {            
            //double ave = (double)Sum() / Count();
            return (double)Sum() / Count();
        }
        public int Min()
        {
            int min = 0;
            for (int i = 0; i < index; i++)
            {
                if (i == 0 || array[i] < min) min = array[i];
            }
            return min;
        }
        public int Max()
        {
            int max = 0;
            for (int i = 0; i < index; i++)
            {
                if (i == 0 || array[i] > max) max = array[i];
            }
            return max;
        }
        public int Search(int item)
        {
            int foundAt = -1;
            for (int i = 0; i < index; i++)
            {
                if(array[i] == item)
                {
                    foundAt = i; break;
                }
            }
            return foundAt;
        }
        public void InsertAt(int index, int item)
        {
            for (int i = this.index; i > index; i--)
            {
                array[i] = array[i - 1];
            }
            array[index] = item;
            this.index++;
        }
        public void RemoveAt(int index)
        {
            if (index < this.index && index >= 0)
            {
                for (int i = index; i <= this.index; i++)
                {
                    array[i] = array[i + 1];
                }
                this.index--;
            }
            else
            {
                throw new Exception("out of bounds...");
            }
        }
        public int[] GetList() //can be used anywhere
        {
            int[] temp = new int[index];
            for (int i = 0; i < index; i++)
            {
                temp[i] = array[i];
            }
            return temp;
        }
    }
}
