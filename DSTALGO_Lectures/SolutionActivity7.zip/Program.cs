﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_Activity7Solution
{
    class Program
    {
        static void Main(string[] args)
        {
            //calling program
            MyList myList = new MyList();
            try
            {
                myList.RemoveAt(45);
            }
            catch { }

            myList.Add(23);myList.PrintList(); Console.ReadLine();
            myList.Add(45); myList.PrintList(); Console.ReadLine();
            myList.Add(12); myList.PrintList(); Console.ReadLine();
            myList.Add(34); myList.PrintList(); Console.ReadLine();
           
            Console.WriteLine("Total Count: " 
                + myList.Count());
            Console.Write("\nSorted List: ");
            myList.Sort(); myList.PrintList(); Console.ReadLine();
            Console.WriteLine("Total SUM: "
                + myList.Sum());
            Console.WriteLine("Average: "
                + myList.Average());
            Console.WriteLine("Min Value: "
                + myList.Min());
            Console.WriteLine("Max Value: "
                + myList.Max());
            Console.WriteLine(12 + " is found @ "
                + myList.Search(12));
            Console.WriteLine(45 + " is found @ "
                + myList.Search(45));
            myList.InsertAt(1, 99);
            Console.ReadLine();
            Console.Write("List CONTENT: ");myList.PrintList();
            myList.InsertAt(2, 100);
            Console.ReadLine();
            Console.Write("List CONTENT: ");myList.PrintList();
            myList.RemoveAt(1);
            Console.ReadLine();
            Console.Write("List CONTENT: ");
            //myList.PrintList();
            foreach (int item in myList.GetList())
            {
                Console.Write("\t" + item);
            }
            Console.ReadLine();
        }
    }
}
