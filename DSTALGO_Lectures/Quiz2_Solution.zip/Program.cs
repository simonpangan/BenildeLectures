﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_SolutionQuiz2
{
    class Program
    {
        static void Main(string[] args)
        {            
            int[] list = new int[5] { 19, 78, 16, 5, 24 };
            int min, temp, counter=0;
            Console.WriteLine("---- Initial Array Content -----");
            foreach (int item in list)
            {
                Console.Write(item + "\t");
            }
            Console.WriteLine("\nPress enter to perform SELECTION sort...");
            Console.ReadLine();
            for (int i = 0; i < list.Length-1; i++) //outer loop i = 0 up to i = 3
            {
                //find the smallest element and store the INDEX
                min = i; //min = 0
                for (int j = i; j < list.Length - 1; j++) //j=4
                {
                       // 24 < 5
                    if (list[j + 1] < list[min]) min = j + 1; //min = 3
                    counter++;
                    //Console.WriteLine("smallest element is " + list[min] + " @ index " + min);
                    //Console.ReadLine();
                }
                //display array content and highlight the smallest element (yellow)
                for (int x = 0; x < list.Length; x++)
                {
                    if (x == min) Console.ForegroundColor = ConsoleColor.Yellow;
                    else
                    {
                        if (x < i) Console.ForegroundColor = ConsoleColor.Green;
                        else Console.ForegroundColor = ConsoleColor.Gray;
                    }
                    Console.Write(list[x] + "\t");
                }
                Console.ReadLine();
                //its time to SWAP the smallest
                temp = list[i];
                list[i] = list[min]; //5
                list[min] = temp; //19

                //display new array content and highlight the SORTED elements (GREEN)
                for (int x = 0; x < list.Length; x++)
                {
                    if (x <= i) Console.ForegroundColor = ConsoleColor.Green;
                    else Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write(list[x] + "\t");
                }
                Console.ReadLine();
            }

            Console.WriteLine("\n-----Sorted List------------");
            Console.ForegroundColor = ConsoleColor.Green;
            foreach (int item in list)
            {
                Console.Write(item + "\t");
            }
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("\nTotal iteration: " + counter);
            
            #region outer iteration 2nd to 4th - manual copy paste
            ////2nd SET of iteration find the smallest element and store the INDEX
            //min = 1; //19
            //for (int j = 1; j < list.Length - 1; j++)
            //{
            //    if (list[j + 1] < list[min]) min = j + 1;

            //    Console.WriteLine("smallest element is " + list[min] + " @ index " + min);
            //    Console.ReadLine();
            //}
            ////its time to SWAP the smallest
            //temp = list[1];
            //list[1] = list[min];
            //list[min] = temp;

            //Console.WriteLine("---- NEW Array Content -----");
            //foreach (int item in list)
            //{
            //    Console.Write(item + "\t");
            //}
            //Console.ReadLine();

            ////3rd SET of iteration find the smallest element and store the INDEX
            //min = 2; //19
            //for (int j = 2; j < list.Length - 1; j++)
            //{
            //    if (list[j + 1] < list[min]) min = j + 1;

            //    Console.WriteLine("smallest element is " + list[min] + " @ index " + min);
            //    Console.ReadLine();
            //}
            ////its time to SWAP the smallest
            //temp = list[2];
            //list[2] = list[min];
            //list[min] = temp;

            //Console.WriteLine("---- NEW Array Content -----");
            //foreach (int item in list)
            //{
            //    Console.Write(item + "\t");
            //}
            //Console.ReadLine();


            ////4th SET of iteration find the smallest element and store the INDEX
            //min = 3; //19
            //for (int j = 3; j < list.Length - 1; j++)
            //{
            //    if (list[j + 1] < list[min]) min = j + 1;

            //    Console.WriteLine("smallest element is " + list[min] + " @ index " + min);
            //    Console.ReadLine();
            //}
            ////its time to SWAP the smallest
            //temp = list[3];
            //list[3] = list[min];
            //list[min] = temp;

            //Console.WriteLine("---- NEW Array Content -----");
            //foreach (int item in list)
            //{
            //    Console.Write(item + "\t");
            //}
            #endregion
            Console.ReadLine();
        }
    }
}
