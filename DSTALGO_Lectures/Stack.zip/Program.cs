﻿using System;
using System.Collections.Generic;
//using System.Collections;

namespace TI102_Stacks
{
    class Program
    {
        static void Main(string[] args)
        {
            //TOPIC: Stack Data Structure
            //Stack myStack1;
            //METHODS: Push, Pop, Peek
            #region Test 1
            //Stack<string> myStack = new Stack<string>(); // LIFO: Last In First Out
            //myStack.Push("Kevin");  //1st item
            //myStack.Push("Simon");  //2nd item
            //myStack.Push("Sherly");  //3rd item

            //Console.WriteLine("the TOP element in the stack is " + myStack.Peek());
            //Console.WriteLine("the TOP element in the stack is " + myStack.Peek());
            //Console.ReadLine();

            //Console.WriteLine("POP my stack: Remove TOP element from the stack: " + myStack.Pop());
            //Console.ReadLine();
            //Console.WriteLine("POP my stack: Remove TOP element from the stack: " + myStack.Pop());
            //Console.ReadLine();
            //Console.WriteLine("POP my stack: Remove TOP element from the stack: " + myStack.Pop());
            //Console.ReadLine();
            //if(myStack.Count>0)
            //    Console.WriteLine("POP my stack: Remove TOP element from the stack: " + myStack.Pop());

            #endregion
            
            int[] numbers = new int[] { 20, 89, 67, 100, 45 };
            
            Console.WriteLine("original array content: ");
            foreach (int item in numbers)
            {
                Console.Write(item + "\t");
            }

            //use a Stack to reverse the content of numbers array
            //TODO: Push(), Pop(), Peek()

            Console.WriteLine("\n\nreverse array content: ");
            foreach (int item in numbers)
            {
                Console.Write(item + "\t");
            }


            //Stack<BrowsingHistory> histories = new Stack<BrowsingHistory>();
            //string url;
            //Console.Write("Enter URL: "); url = Console.ReadLine();
            //histories.Push(new BrowsingHistory(url));
            //Console.Write("Enter next URL: "); url = Console.ReadLine();
            //histories.Push(new BrowsingHistory(url));
            //Console.Write("Enter next URL: "); url = Console.ReadLine();
            //histories.Push(new BrowsingHistory(url));

            //Console.WriteLine("Your current site is " + histories.Peek().URL);
            //Console.WriteLine("Press enter to go back from previous site...");
            //Console.ReadLine();
            //histories.Pop();
            //Console.WriteLine("Your current site is " + histories.Peek().URL);
            //Console.WriteLine("Press enter to go back from previous site...");

            //Console.ReadLine();
            //histories.Pop();
            //Console.WriteLine("Your current site is " + histories.Peek().URL);
            //Console.WriteLine("Press enter to go back from previous site...");


            Console.ReadLine();
        }
    }

    class BrowsingHistory
    {
        public string URL { get; set; }
        public DateTime AccessDateTime { get; set; }
        public BrowsingHistory(string url)
        {
            URL = url;
            AccessDateTime = DateTime.Now;
        }
    }
}
