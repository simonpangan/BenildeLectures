﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_GenericList
{
    class Program
    {
        static void Main(string[] args)
        {
            
            object x = 45;
            object y = "Hello";
            object z = true;
            object w = 78.9045;
            object p = new Person();

            int sum = (int)x + 50; //cast an object to its specific type
            double grade = (double)w;

            MyList<int> list = new MyList<int>();
            list.Add(34);
            list.Add(56);
            list.Add(12);
            list.Add(56);
            list.Add(23);            
            int total = 0;
            Console.WriteLine("List of Numbers:");
            foreach (int item in list.GetList())
            {
                Console.Write(item + "\t");
                total += item;
            }
            Console.WriteLine("\n\nTotal is " + total);

            MyList<string> names = new MyList<string>();
            names.Add("Joed");names.Add("Simon");
            names.Add("Ryan");names.Add("Kyle");
            Console.WriteLine("\n\nList of String:");
            foreach (var item in names.GetList())
            {
                Console.Write(item + "\t");
            }

            //we try to imitate the behaviour of:
            List<Student> listOfStudents;

            MyList<Student> students = new MyList<Student>();
            students.Add(new Student("Goh", 89.67));
            students.Add(new Student("Pangan", 90.56));
            students.Add(new Student("Obeles", 95.00));
            Console.WriteLine("\n\nList of Students:");
            Console.WriteLine("Student        TermGrade");
            foreach (var item in students.GetList())
            {
                Console.WriteLine(item.Lastname + "\t\t" +
                    item.TermGrade);
            }

            //list.Add("Hello");
            //list.Add(true);
            //list.Add("Hello"); //cannot add because not of type int
            //list.PrintList();
            /*int total = 0;
            foreach (object item in list.GetList())
            {
                if (item.GetType() == typeof(int))
                {
                    Console.Write(item + "\t");
                    total += (int)item;
                }
            }*/

            Console.ReadLine();
        }
    }

    class Person
    {
        public string Lastname { get; set; }
    }
    class Student:Person
    {
        public double TermGrade { get; set; }
        public Student(string lname, double grade)
        {
            Lastname = lname; TermGrade = grade;
        }
    }
    class Teacher:Person
    {

    }
}
