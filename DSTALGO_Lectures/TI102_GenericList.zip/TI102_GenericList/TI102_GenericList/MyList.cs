﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_GenericList
{
    //Array of Objects implementation
    //class MyList
    //{
    //    object[] array;
    //    int index;
    //    public MyList()
    //    {
    //        array = new object[5]; //default size
    //        index = 0; //keeps track of our items inside your array: dictates the size
    //    }
    //    public void Add(object item)
    //    {
    //        //no restrcition yet
    //        array[index] = item;
    //        index++;
    //    }
    //    public object[] GetList()
    //    {
    //        object[] temp = new object[index];
    //        for (int i = 0; i < index; i++)
    //        {
    //            temp[i] = array[i];
    //        }
    //        return temp;
    //    }
    //    public void PrintList()
    //    {
    //        for (int i = 0; i < index; i++)
    //        {
    //            Console.Write(array[i] + "\t");
    //        }
    //    }
    //}

    //TODO methods:
    //InsertAt 
    //RemoveAt
    //Clear

    class MyList<T>    //Generic List implementation
    {
        T[] array;  //not fix int nor fix object (too generalize)
        int index;
        public MyList()
        {
            array = new T[5]; //default size
            index = 0; //keeps track of our items inside your array: dictates the size
        }
        public void Add(T item)
        {
            //no restrcition yet
            array[index] = item;
            index++;
        }
        public T[] GetList()
        {
            T[] temp = new T[index];
            for (int i = 0; i < index; i++)
            {
                temp[i] = array[i];
            }
            return temp;
        }
        public void PrintList()
        {
            for (int i = 0; i < index; i++)
            {
                Console.Write(array[i] + "\t");
            }
        }
        //TODO methods:
        //InsertAt 
        //RemoveAt
        //Clear
    }
}
