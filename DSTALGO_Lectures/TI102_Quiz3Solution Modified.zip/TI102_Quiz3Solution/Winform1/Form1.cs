﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyCollection;
using TI102_Quiz3Solution;
namespace Winform1
{
    public partial class Form1 : Form
    {
        MyList<Car> listOfCars;
        Queue<Car> carQueue;
        public Form1()
        {
            InitializeComponent();
            listOfCars = new MyList<Car>();
            carQueue = new Queue<Car>();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int ym = int.Parse(txtYearModel.Text);
            listOfCars.Add(new Car(txtMaker.Text, ym, cboColor.Text));
            populateGridview();
        }
        private void populateGridview()
        {
            dataGridView1.DataSource = carQueue.ToList(); //listOfCars.GetList();
        }
        private void btnReverse_Click(object sender, EventArgs e)
        {
            listOfCars.Reverse();
            populateGridview();
        }

        private void btnEnqueue_Click(object sender, EventArgs e)
        {
            int ym = int.Parse(txtYearModel.Text);
            carQueue.Enqueue(new Car(txtMaker.Text, ym, cboColor.Text));
            populateGridview();
        }
        private void btnDequeue_Click(object sender, EventArgs e)
        {
            if(carQueue.Count>0)
            {
                carQueue.Dequeue();
                populateGridview();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The topmost car in your collection is:\n"
                + carQueue.Peek().GetDetails(), "TOP Car", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
