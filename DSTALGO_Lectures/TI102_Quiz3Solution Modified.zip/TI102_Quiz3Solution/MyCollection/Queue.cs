﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCollection
{
    //public class Queue <T>
    //{
    //    //todo
    //    //todo
    //    T[] array = new T[5];
    //    public int Count { get; }
    //    public void Enqueue(T item) //similar Push
    //    {
    //        //todo
    //    }
    //    //public T Peek() //view topmost element
    //    //{
    //    //    //todo
    //    //    T topmost;
    //    //    return topmost;
    //    //}

    //    //public T Dequeue() //similar to Pop
    //    //{
    //    //    //todo
    //    //    T topmost;
    //    //    return topmost;
    //    //}
    //}
}
