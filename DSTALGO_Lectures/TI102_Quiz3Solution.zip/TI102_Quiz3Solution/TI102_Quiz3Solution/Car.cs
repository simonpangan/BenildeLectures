﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_Quiz3Solution
{
    //class is similar to your dbase table structure
    //object is similar to a record in a dbase table
    class Car 
    {
        public string Maker { get; set; }
        public int YearModel { get; set; }
        public string Color { get; set; }
        public Car() //default constructor
        {
            Maker = "Toyota";
            YearModel = 2019;
            Color = "White";
        }
        public Car(string maker, int yearModel, string color)//overloaded constructor: with parameter
        {
            Maker = maker;
            YearModel = yearModel;
            Color = color;
        }
        public string GetDetails()
        {
            return Maker + "\t" + YearModel + "\t" + this.Color;
        }
    }
}
