﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyCollection;

namespace TI102_Quiz3Solution
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Car car1 = new Car();            

            MyList<Car> myCars = new MyList<Car>();
            myCars.Add(car1);
            myCars.Add(new Car());
            myCars.Add(new Car("Honda", 2017, "Black"));
            //Add
            foreach (Car item in myCars.GetList())
            {
                Console.WriteLine(item.GetDetails());
            }
            Console.ReadLine();

            //Insert
            myCars.InsertAt(1, new Car("Kia", 2009, "Purple"));
            foreach (Car item in myCars.GetList())
            {
                Console.WriteLine(item.GetDetails());
            }
            Console.ReadLine();
            //Remove
            myCars.Remove(0);
            foreach (Car item in myCars.GetList())
            {
                Console.WriteLine(item.GetDetails());
            }

            //reverse
            Console.ReadLine();
            myCars.Reverse();
            foreach (Car item in myCars.GetList())
            {
                Console.WriteLine(item.GetDetails());
            }            
            Console.ReadLine();
        }
    }
   
}
