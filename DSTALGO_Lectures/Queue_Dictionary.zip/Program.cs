﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_Queue_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            #region stack vs queue
            ////STACK: LIFO
            //Stack<string> stack1 = new Stack<string>();
            //stack1.Push("Simon");
            //stack1.Push("Ryan");
            //stack1.Push("Dominic");

            //stack1.Pop();
            //Console.WriteLine("Top element of Stack is " + stack1.Peek()); Console.ReadLine();

            ////QUEUE: FIFO First In First Out
            //Queue<string> queue1 = new Queue<string>();
            //queue1.Enqueue("Simon"); //Adding an element similar to Push in a Stack
            //queue1.Enqueue("Ryan"); //Adding an element similar to Push in a Stack
            //queue1.Enqueue("Dominic"); //Adding an element similar to Push in a Stack
            //queue1.Dequeue();

            //Console.WriteLine("Top element of QUEUE is " + queue1.Peek()); Console.ReadLine();
            #endregion

            #region  Key-Value Pair using Array
            //int[] ids = { 101, 102, 103, 103, 105 };
            //string[] names = { "Simon", "Ryan", "Dominic", "Kevin", "Kyle" };
            //int id, index = -1;
            //string name;

            //Console.Write("Enter ID: "); int.TryParse(Console.ReadLine(), out id);

            //for (int i = 0; i < ids.Length; i++)
            //{
            //    if (id == ids[i])
            //    {
            //        index = i; break; //get the first 
            //    }
            //}
            //if (index > -1)
            //{
            //    name = names[index];
            //    Console.WriteLine("the name is " + name);
            //}
            //else
            //    Console.WriteLine("id cannot be found...");
            #endregion

            //key must be unique
            Dictionary<int, Product> dictionary2 = new Dictionary<int, Product>();

            Dictionary<int, string> dictionary1 = new Dictionary<int, string>();
            dictionary1.Add(101, "Simon");
            dictionary1.Add(102, "Ryan");
            dictionary1.Add(103, "Dominic");
            dictionary1.Add(104, "Kevin");
            dictionary1.Add(105, "Kyle");

            int id; string name; bool found;
            Console.Write("Enter ID: "); int.TryParse(Console.ReadLine(), out id);
            found = dictionary1.TryGetValue(id, out name);
            if (found) Console.WriteLine("The name is " + name);
            else Console.WriteLine("Unable to found " + id);

            Console.WriteLine("List of Keys: ");
            foreach (var item in dictionary1.Keys)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n\nList of Values: ");
            foreach (var item in dictionary1.Values)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n\nList of dictionary items: ");
            foreach (var item in dictionary1)
            {
                Console.WriteLine(item.Key + "\t" + item.Value);
            }

            
            Console.ReadLine();
        }
    }

    class Product
    {
        public string Description { get; set; }
        public DateTime Expiration { get; set; }

    }
}
