﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TI102_ADTWinform
{
    public partial class Form1 : Form
    {
        ThakwaniList myList;
        public Form1()
        {
            InitializeComponent();
            myList = new ThakwaniList();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int item;
            int.TryParse(txtItem.Text, out item);
            myList.Add(item);
            MessageBox.Show("Item has been added...", "Add Item", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtItem.Clear();
            txtItem.Focus();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (int item in myList.GetList())
            {
                listBox1.Items.Add(item);
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            myList.Sort();
            btnView_Click(null, null);
        }
    }
}
