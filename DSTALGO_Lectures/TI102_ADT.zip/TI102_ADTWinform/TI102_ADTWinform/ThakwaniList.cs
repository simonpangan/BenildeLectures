﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_ADTWinform
{
    class ThakwaniList
    {
        private int[] array;
        private int index = 0;
        public ThakwaniList() //special method: Constructor: executed as a new object is created
        {
            //initialize everything
            array = new int[10];
        }
        public void Add(int item)
        {
            array[index] = item;
            index++;
        }
        public void PrintList()
        {
            for (int i = 0; i < index; i++)
            {
                Console.Write("\t" + array[i]);
            }
        }
        public void Sort()
        {
            int temp;
            for (int i = 1; i < index; i++)//insertion sort
            {
                bool swap = true; int insertAt = i;
                for (int j = i; j > 0 && swap; j--)
                {
                    if (array[j] < array[j - 1])
                    {
                        temp = array[j - 1];
                        array[j - 1] = array[j];
                        array[j] = temp; // swap
                        swap = true;
                        insertAt = j - 1;
                    }
                    else swap = false;
                }
            }
        }
        public int[] GetList()
        {
            int[] temp = new int[index];
            for (int i = 0; i < index; i++)
            {
                temp[i] = array[i];
            }
            return temp;
        }
    }
}
