﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_Lecture03
{
    class Program
    {
        //May 24 (FRI). anticipated make-up class 12-3PM
        static void Main(string[] args)
        {
            //cont. arrays
            //Linear DS: Accessing -> direct vs Sequential
            int[] numbers = new int[5]; //default 0
            double[] grades = new double[3] {90.50, 70, 100 };
            double[] prices = new double[] {1500, 1999.50, 5000, 150.75 }; //set size to 4: implied
            char[] choices = new char[4] { 'A', 'B', 'C', 'D' };
            string[] names = new string[] { "MATTHEW", "SIMON", "ROSHAN", "SEVILLA", "GLENMARK" };//5
                                                                                                  //index  0        1           2       3           4
                                                                                                  //direct access
                                                                                                  //Console.WriteLine( names[3]);
                                                                                                  //Console.WriteLine(names[5]);//error -> out of bounds

            //sequential access
            Console.WriteLine("-----------using for loop ----------------");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine(names[i]); //array travesal->navigating
            }

            //foreach loop?
            int counter = 0;
            Console.WriteLine("\n-----------using foreach loop ----------------");
            foreach(string item in names)
            {
                counter++;
                Console.WriteLine(item);
                if (counter == 3) break;
            }


            Console.ReadLine();
        }
    }
}
