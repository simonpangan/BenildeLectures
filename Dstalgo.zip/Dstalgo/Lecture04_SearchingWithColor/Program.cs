﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_Lecture04
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int[] numbers = new int[100];
            int itemSearch, count = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = r.Next(100); //0 to 99 random numbers
            }
            do
            {
                Console.Clear(); Console.ResetColor();
                Console.WriteLine("LIST of RANDOM 100 numbers");
                Console.WriteLine("---------------------------------------------------------");
                foreach (int item in numbers)
                {
                    Console.Write(item + "\t");
                }
                Console.Write("\n\nEnter item to be searched: ");
                Console.ForegroundColor = ConsoleColor.Green;
                int.TryParse(Console.ReadLine(), out itemSearch);
                Console.ForegroundColor = ConsoleColor.Gray;

                //basic sequential searching
                foreach (int item in numbers)
                {
                    if (item == itemSearch) count++;
                }

                Console.ForegroundColor = ConsoleColor.Green; Console.Write(itemSearch);
                Console.ForegroundColor = ConsoleColor.Gray; Console.Write(" has been found ");
                Console.ForegroundColor = ConsoleColor.Green; Console.Write(count);
                Console.ForegroundColor = ConsoleColor.Gray; Console.Write(" time(s)");

                Console.SetCursorPosition(0, 2);
                foreach (int item in numbers)
                {
                    if (item == itemSearch) Console.ForegroundColor = ConsoleColor.Yellow;
                    else Console.ForegroundColor = ConsoleColor.White;
                    Console.Write(item + "\t");
                }
                Console.WriteLine("Please press enter key to continue...");
                Console.ReadLine();
                
            } while (true);

            Console.ReadLine();
        }
    }
}
