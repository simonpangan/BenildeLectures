﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_Lecture02
{
    class Program
    {
        static void Main(string[] args)
        {
            //int a, b, c, d, e;
            int[] numbers = new int[100];
            //while, do while, for loop
            for (int i = 0; i < numbers.Count(); i++)
            {
                Console.Write("Enter number " + (i+1) + ": "); int.TryParse(Console.ReadLine(), out numbers[i]);//a                
            }
            Console.Write("You have entered: ");
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write("\t" + numbers[i]);
            }
                        
            //Console.Write("You have entered:\t" + a + "\t" + b + "\t" + c + "\t" + d + "\t" + e);

            Console.ReadLine();
        }
    }
}
