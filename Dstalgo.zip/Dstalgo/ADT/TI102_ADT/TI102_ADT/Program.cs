﻿using System;
using System.Collections.Generic; //several data structures
using System.Linq; //manipulate collection/datasets using SQL like/ method syntax
using System.Text;
using System.Threading.Tasks;

namespace TI102_ADT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Type       refVar = Constructor;
            ThakwaniList myList = new ThakwaniList(); //instantiate a class to create an OBJECT
            myList.Add(90);
            myList.Add(100);
            //myList.index = 7845;
            myList.Add(45);
            Console.Write("\nUnsorted List Content: ");
            foreach (int item in myList.GetList())
            {
                Console.Write("\t" + item);
            }

            myList.Sort(); Console.ReadLine();
            Console.Write("\nSORTED List Content: ");
            myList.PrintList();


            #region array vs generic list
            //using an array
            //int[] myList = new int[10];
            //myList[0] = 90;
            //myList[1] = 45;
            //myList[2] = -189;
            //myList[3] = 100;

            //List<int> myList = new List<int>(); //using generic list
            //myList.Add(90);
            //myList.Add(45);
            //myList.Add(45);
            //myList.Add(45);
            //myList.Add(-189);
            //myList.Add(100);
            //myList.Remove(45);
            //myList.RemoveAt(0);
            //myList.Insert(1, 200);
            //Console.Write("List content: ");
            //foreach (int item in myList)
            //{
            //    Console.Write("\t" + item);
            //}

            //myList.Sort();
            //Console.Write("\n\nSORTED List content: ");
            //foreach (int item in myList)
            //{
            //    Console.Write("\t" + item);
            //}

            //Console.WriteLine("\n\nSUM is : " + myList.Sum());
            //Console.WriteLine("Average is : " + myList.Average());
            #endregion
            Console.ReadLine();
        }
    }
}
