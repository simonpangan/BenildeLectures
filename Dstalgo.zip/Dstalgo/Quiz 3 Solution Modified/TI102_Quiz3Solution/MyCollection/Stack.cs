﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCollection
{
    public class Stack<T>
    {

        //todo
        T[] array = new T[5];
        public int Count { get; }
        public void Push(T item)
        {
            //todo
        }
        //public T Peek()
        //{
        //    //todo
        //    T topmost;
        //    return topmost;
        //}

        //public T Pop()
        //{
        //    //todo
        //    T topmost;
        //    return topmost;
        //}
    }
}
