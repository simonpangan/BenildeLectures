﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_SolutionActivity5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[8];// { 41, 1, 67, 78, 99};
            int temp, loops = 0 ; Random r = new Random();
            Console.WriteLine("--- Initial Array Content ---");
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = r.Next(100);
                Console.Write(numbers[i] + "\t");
            }
            Console.WriteLine("\nNow performing bubble sort...");
            //algo
            //1st checking
            for (int i=numbers.Length-1; i>0; i--)////count i from 4 to 1 = 4 times
            {
                bool exit = true; bool swap = false;
                //Console.ReadLine();
                Console.WriteLine("------       @ i = " + i + "------");
                for (int j = 0; j < i; j++) //count j from 0 to 3  = 4 times
                {
                    Console.ReadLine();
                    //Console.WriteLine("------       @ j = " + j + "------");
                    if (numbers[j] > numbers[j + 1]) //swap
                    {
                        temp = numbers[j];
                        numbers[j] = numbers[j + 1];
                        numbers[j + 1] = temp;
                        exit = false; swap = true;
                    }
                    //display all elements
                    for (int x = 0; x < numbers.Length; x++)
                    {
                        if (x == j + 1)
                        {
                            if (swap) Console.ForegroundColor = ConsoleColor.Green; // BUBBLE UP
                            else Console.ForegroundColor = ConsoleColor.Yellow; // AS IS
                            swap = false;
                        }
                        
                        Console.Write(numbers[x] + "\t");
                        Console.ForegroundColor = ConsoleColor.Gray;
                    }
                    loops++;
                }
                Console.WriteLine("\n iterating j is done....\n");
                if (exit) break; //get out of the outer loop because NO SWAP happened
            }

            Console.WriteLine("\nNumber of iterations: " + loops);
            #region outer loop (manual)
            ////2nd checking
            //for (int j = 0; j < 4; j++) //count from 0 to 3
            //{
            //    Console.ReadLine();
            //    Console.WriteLine("------       @ j = " + j + "------");
            //    if (numbers[j] > numbers[j + 1]) //swap
            //    {
            //        temp = numbers[j];
            //        numbers[j] = numbers[j + 1];
            //        numbers[j + 1] = temp;
            //    }
            //    //display all elements
            //    for (int x = 0; x < numbers.Length; x++)
            //    {
            //        Console.Write(numbers[x] + "\t");
            //    }
            //}

            ////3rd checking
            //for (int j = 0; j < 4; j++) //count from 0 to 3
            //{
            //    Console.ReadLine();
            //    Console.WriteLine("------       @ j = " + j + "------");
            //    if (numbers[j] > numbers[j + 1]) //swap
            //    {
            //        temp = numbers[j];
            //        numbers[j] = numbers[j + 1];
            //        numbers[j + 1] = temp;
            //    }
            //    //display all elements
            //    for (int x = 0; x < numbers.Length; x++)
            //    {
            //        Console.Write(numbers[x] + "\t");
            //    }
            //}

            ////4th checking
            //for (int j = 0; j < 4; j++) //count from 0 to 3
            //{
            //    Console.ReadLine();
            //    Console.WriteLine("------       @ j = " + j + "------");
            //    if (numbers[j] > numbers[j + 1]) //swap
            //    {
            //        temp = numbers[j];
            //        numbers[j] = numbers[j + 1];
            //        numbers[j + 1] = temp;
            //    }
            //    //display all elements
            //    for (int x = 0; x < numbers.Length; x++)
            //    {
            //        Console.Write(numbers[x] + "\t");
            //    }
            //}
            #endregion
            #region manual checking SWAP
            ////2nd checking
            //Console.ReadLine();
            //if (numbers[1] > numbers[2]) //swap
            //{
            //    temp = numbers[1];
            //    numbers[1] = numbers[2];
            //    numbers[2] = temp;
            //}
            ////display all elements
            //for (int x = 0; x < numbers.Length; x++)
            //{
            //    Console.Write(numbers[x] + "\t");
            //}
            ////3rd checking
            //Console.ReadLine();
            //if (numbers[2] > numbers[3]) //swap
            //{
            //    temp = numbers[2];
            //    numbers[2] = numbers[3];
            //    numbers[3] = temp;
            //}
            ////display all elements
            //for (int x = 0; x < numbers.Length; x++)
            //{
            //    Console.Write(numbers[x] + "\t");
            //}
            ////4th checking
            //Console.ReadLine();
            //if (numbers[3] > numbers[4]) //swap
            //{
            //    temp = numbers[3];
            //    numbers[3] = numbers[4];
            //    numbers[4] = temp;
            //}
            ////display all elements
            //for (int x = 0; x < numbers.Length; x++)
            //{
            //    Console.Write(numbers[x] + "\t");
            //}
            #endregion
            Console.ReadLine();
        }
    }
}
