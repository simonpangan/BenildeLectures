﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TI102_InsertionSort
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] list = new int[5] {8, 5, 7, 1, 9};
            int temp, counter = 0;
            Console.WriteLine("---- Initial Array Content -----");
            foreach (int item in list)
            {
                Console.Write(item + "\t");
            }
            Console.Write("\n\nPress enter to perform insertion sort..."); Console.ReadLine();

            //Insertion sort
            for (int i = 1; i < list.Length; i++) // i = 1 ... i = 4
            {
                //highlight element to be INSERTED
                for (int x = 0; x < list.Length; x++)
                {
                    if (x == i) Console.ForegroundColor = ConsoleColor.Yellow;
                    else Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write(list[x] + "\t");
                }
                Console.ReadLine();

                bool swap = true; int insertedAt = i;
                for (int j = i; j > 0 && swap; j--)
                {
                    counter++;
                    if (list[j] < list[j - 1])
                    {
                        temp = list[j - 1]; list[j - 1] = list[j]; list[j] = temp; //swap
                        swap = true;
                        insertedAt = j - 1;
                    }
                    else swap = false;                                        
                    //if (!swap) break;                    
                }
                //highlight element AFTER the insertion
                for (int x = 0; x < list.Length; x++)
                {
                    if (x == insertedAt) Console.ForegroundColor = ConsoleColor.Green;
                    else Console.ForegroundColor = ConsoleColor.Gray;
                    Console.Write(list[x] + "\t");
                }
                Console.ReadLine();
            }

            Console.WriteLine("\n\nTotal Iteration: " + counter);

            #region 2nd to 4th iteration
            ////2nd set of iteration
            //for (int j = 2; j > 0; j--)
            //{
            //    if (list[j] < list[j - 1])
            //    {
            //        temp = list[j - 1]; list[j - 1] = list[j]; list[j] = temp; //swap
            //    }

            //    for (int x = 0; x < list.Length; x++)
            //    {
            //        Console.Write(list[x] + "\t");
            //    }
            //    Console.ReadLine();
            //}
            ////3rd set of iteration
            //for (int j = 3; j > 0; j--)
            //{
            //    if (list[j] < list[j - 1])
            //    {
            //        temp = list[j - 1]; list[j - 1] = list[j]; list[j] = temp; //swap
            //    }

            //    for (int x = 0; x < list.Length; x++)
            //    {
            //        Console.Write(list[x] + "\t");
            //    }
            //    Console.ReadLine();
            //}
            ////4th set of iteration
            //for (int j = 4; j > 0; j--)
            //{
            //    if (list[j] < list[j - 1])
            //    {
            //        temp = list[j - 1]; list[j - 1] = list[j]; list[j] = temp; //swap
            //    }

            //    for (int x = 0; x < list.Length; x++)
            //    {
            //        Console.Write(list[x] + "\t");
            //    }
            //    Console.ReadLine();
            //}
            #endregion
            #region manual if statement to test iteartion 2nd to 4th
            ////2nd set of iteration
            //if (list[2] < list[1])
            //{
            //    temp = list[1]; list[1] = list[2]; list[2] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();

            //if (list[1] < list[0])
            //{
            //    temp = list[0]; list[0] = list[1]; list[1] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();


            ////3rd set of iteration
            //if (list[3] < list[2])
            //{
            //    temp = list[2]; list[2] = list[3]; list[3] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();

            //if (list[2] < list[1])
            //{
            //    temp = list[1]; list[1] = list[2]; list[2] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();

            //if (list[1] < list[0])
            //{
            //    temp = list[0]; list[0] = list[1]; list[1] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();

            ////4th set of iteration
            //if (list[4] < list[3])
            //{
            //    temp = list[3]; list[3] = list[4]; list[4] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();

            //if (list[3] < list[2])
            //{
            //    temp = list[2]; list[2] = list[3]; list[3] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();

            //if (list[2] < list[1])
            //{
            //    temp = list[1]; list[1] = list[2]; list[2] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            //Console.ReadLine();

            //if (list[1] < list[0])
            //{
            //    temp = list[0]; list[0] = list[1]; list[1] = temp; //swap
            //}

            //for (int x = 0; x < list.Length; x++)
            //{
            //    Console.Write(list[x] + "\t");
            //}
            #endregion
            Console.ReadLine();
        }
    }
}
