﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCollection
{
    public class Stack<T>
    {
        //todo
        public void Push(T item)
        {
            //todo
        }
    }
}
