﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MyCollection
{
    public class MyList<T>
    {
        T[] array = new T[5];
        int index = 0;
        public void Add(T item)
        {
            array[index] = item; //adding of a new object/record   
            index++; //positions to the next available location
        }
        public void InsertAt(int index, T item)
        {
            for (int i = this.index; i > index; i--)
            {
                //right <- left item
                array[i] = array[i - 1];
            }
            array[index] = item;
            this.index++;
        }
        public void Remove(int index)
        {
            for (int i = index; i < this.index; i++)
            {
                array[i] = array[i + 1];
            }
            this.index--;
        }
        public void Reverse()
        {
            System.Collections.Generic.Stack<T> stack = new System.Collections.Generic.Stack<T>();
            for (int i = 0; i < index; i++)
            {
                stack.Push(array[i]);
            }
            for (int i = 0; i < index; i++)
            {
                array[i] = stack.Pop();
            }
        }
        public T[] GetList()
        {
            T[] temp = new T[index];
            for (int i = 0; i < index; i++)
            {
                temp[i] = array[i];
            }
            return temp;
        }
    }

 
}
