﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCollection
{
    public class Queue <T>
    {
        //todo
        public void Enqueue(T item)
        {
            //todo
        }
    }
}
